

class Sentence(list):
    """This class represents the sentence separated from turn"""
    def __init__(self,sent):
        super(Sentence,self).__init__(sent)
